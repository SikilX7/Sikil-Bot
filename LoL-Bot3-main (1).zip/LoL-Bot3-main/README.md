<div align="center">
Hello ~ I'm Pxc7<img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Hi.gif" width="35px">
<img src="https://i.ibb.co/GQcDxdZ/IMG-20210329-WA0485.jpg" alt="Pxc7" width="500" />
<p align="center">
  <a href="https://github.com/Pxc7/LoL-Bot3#installation">Installation</a> •
  <a href="https://github.com/Pxc7/LoL-Bot3#thanks-to">Thanks Too</a> •
  <a href="https://github.com/Pxc7/LoL-Bot3#TROPY">Tropy</a> •
  <a href="https://github.com/Pxc7/LoL-Bot3#JUMLAH-VIEWS">Views</a> •
  <a href="https://github.com/Pxc7/LoL-Bot3#STATUS">Status</a> •
  <a href="https://github.com/Pxc7/LoL-Bot3#LANGUAGE">Language</a> 
</p>

![JavaScript](https://img.shields.io/badge/-JavaScript-black?style=flat-square&logo=javascript) |
![Nodejs](https://img.shields.io/badge/-Nodejs-black?style=flat-square&logo=Node.js) |
![Python](https://img.shields.io/badge/-Python-black?style=flat-square&logo=Python)

<p align="center">
<a href="https://youtube.com/channel/UC85BV5PuFNdhEF1JIR6mKjw"><img height="75" src="https://i.ibb.co/fxgb1JS/472b4d8d3ab7fcc3be2fc0e8353a5350.png"></a>&nbsp;&nbsp;
</p>

# _**PERHATIKAN**_
</div>

# Installation

##  _Termux_
```cmd
> pkg update && pkg upgrade
> pkg install git -y
> pkg install nodejs -y
> pkg install ffmpeg -y
```

## _Cloning_
```cmd
> git clone https://github.com/Pxc7/LoL-Bot3
> cd LoL-Bot3
```

## _Install_
```cmd
> npm i
```

## _Run the LoL-Bot3_
```cmd
> npm start
```

## _INFO TENTANG GW_<img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/powerup.gif" width="29px">
* [![Instagram Badge](https://img.shields.io/badge/-dokidokinime-purple?style=flat-square&logo=instagram&logoColor=white&link=https://instagram.com/dokidokinime/)](https://instagram.com/dokidokinime)
* [![Youtube Badge](https://img.shields.io/badge/-Mr.A43G-darkred?style=flat-square&logo=youtube&logoColor=white&link=https://youtube.com/channel/UC85BV5PuFNdhEF1JIR6mKjw)](https://youtube.com/channel/UC85BV5PuFNdhEF1JIR6mKjw)
* [![Whatsapp Badge](https://img.shields.io/badge/-Riu-darkgreen?style=flat-square&logo=whatsapp&logoColor=white&link=https://wa.me/62814622392081)](https://wa.me/62814622392081)


# *Thanks To*
* [![Github Badge](https://img.shields.io/badge/-Baileys-black?style=flat-square&logo=github&logoColor=white&link=https://github.com/adiwajshing/Baileys)](https://github.com/adiwajshing/Baileys)
* [![Github Badge](https://img.shields.io/badge/-Fxc7-black?style=flat-square&logo=github&logoColor=white&link=https://github.com/Fxc7)](https://github.com/Fxc7)
* [![Github Badge](https://img.shields.io/badge/-LoLHuman-black?style=flat-square&logo=github&logoColor=white&link=https://github.com/LoL-Human)](https://github.com/LoL-Human)
* [![Github Badge](https://img.shields.io/badge/-Arnando-black?style=flat-square&logo=github&logoColor=white&link=https://github.com/Arnando456)](https://github.com/Arnando456)
* [![Github Badge](https://img.shields.io/badge/-Sofyen-black?style=flat-square&logo=github&logoColor=white&link=https://github.com/SofyanAMV09)](https://github.com/SofyanAMV09)
* [![Github Badge](https://img.shields.io/badge/-Rio-black?style=flat-square&logo=github&logoColor=white&link=https://github.com/Itz-Rio-Bruh)](https://github.com/Itz-Rio-Bruh)

## STATUS🎌
![Github Stats](https://github-readme-stats.vercel.app/api?username=Pxc7&count_private=true&show_icons=true&include_all_commits=true)

## LANGUAGE📄
![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=Pxc7&count_private=true&show_icons=compact&theme=onedark)

## TROPY🏆
![](https://github-profile-trophy.vercel.app/?username=Pxc7&row=2&column=3&layout=compact&theme=onedark)

## JUMLAH VIEWS👀
<p align="center">
  <img src="https://komarev.com/ghpvc/?username=Pxc7&label=VIEW&style=flat-square&color=orange" />
</p>

End Udahan Buat Full Lolhuman
